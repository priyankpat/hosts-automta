#!/bin/bash

# Get the latest updated hosts file and put it into place
sudo wget https://gist.githubusercontent.com/priyankpat/68a6f96ed1e3fbe974fe1f573248b1ff/raw/f5303543cbed28421bfcfcbd0451e59fb0441eb2/gistfile1.txt -O /etc/hosts

exit 0