#!/bin/bash

# Get the latest updated hosts file and put it into place
sudo mv ./hosts /etc/hosts

exit 0