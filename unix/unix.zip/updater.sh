#!/bin/bash

# Get the latest updated hosts file and put it into place
sudo wget https://gist.githubusercontent.com/priyankpat/68a6f96ed1e3fbe974fe1f573248b1ff/raw/5db9ed7a2bc80220d882c3e73f2a8714498c5b02/gistfile1.txt -O /etc/hosts

exit 0