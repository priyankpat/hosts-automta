#!/bin/bash

# Replace our original hosts file
sudo mv /etc/hosts.bak /etc/hosts

exit 0